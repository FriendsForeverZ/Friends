# FriendAtlas: Interactive Friend Network Graph & Social Matrix

An interactive, high-performance network visualization and friend-circle map inspired by streamer network graphs (TwitchAtlas). It visualizes friendship networks, communication density, shared communities, and multi-group connector/bridge friends with glowing particle aesthetics, live force physics, interactive connection drawing, and a password-protected secret admin management console.

> [!IMPORTANT]
> **Key Architecture Decisions:**
> - **Visual Style & Render Engine**: High-FPS HTML5 Canvas + WebGL-grade particle effects with custom force-directed simulation (d3-force physics) for silky 60fps interaction, zoom/pan, dragging, and animated connection pulses.
> - **Bridge Node ("Связующее звено") Detection**: Automated network topology analysis calculating multi-cluster membership and betweenness. Bridge friends get dynamic dual-color glowing gradients that shimmer between their connected groups, with spatial physics positioning them between communities.
> - **Scale-by-Degree**: Dynamic node sizing ($r \propto \sqrt{\text{degree}} \times \text{weight}$) with smooth scaling, high-res avatar clipping, and adaptive label sizing.
> - **Secret Admin Console**: Accessible via secret key shortcut (`Ctrl + Shift + A`) or a discreet lock button with customizable secret nickname and master password. Supports node addition with web image URLs, edge creation with closeness weights, automated community re-clustering, and full JSON export/import backup.
> - **Zero-Loss Presets**: Preloaded with a vibrant gaming and friend-circle dataset featuring well-known archetypes and bridge figures to demonstrate animated links and community overlap out of the box.

---

## 1. Overview & Core Concept

- **What It Does**: FriendAtlas renders an interactive, space-grade social graph of a friend group. Clicking or hovering on any person draws animated glowing beam connections to their friends, dims irrelevant nodes, and reveals detailed communication stats, mutual friends, and shared interests.
- **Target Audience / Persona**: Friend groups, gaming communities, Discord servers, and student circles who want an awesome interactive map of "who hangs out with whom", showing clusters and the social butterflies connecting different groups.
- **Key Value**: Makes complex social bonds visual, engaging, and alive with shimmering animations, automatic community clustering, and effortless self-hosted admin control.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Interactive Exploration & Discovery**:
   - The user opens the app to a dark cosmic canvas populated by glowing nodes grouped by social circles.
   - Hovering over a friend highlights them and their immediate neighbors, dims the rest of the galaxy, and shows glowing connection lines.
   - Clicking a friend locks focus, animates the camera to center on them, and slides open an inspect card with:
     - Avatar & nickname
     - Closeness level & mutual friends
     - Community affiliations (including dual/bridge breakdown)
     - Shared tags and favorite hangout activities
2. **Filters & Community Toggles**:
   - Top floating toolbar allows filtering by **Community Group** (e.g., *Discord Gamers*, *IRL Crew*, *Tech Pals*, *Music & Festival*) or by **Interests/Tags** (e.g., *CS2*, *Dota*, *Anime*, *Night Talks*).
   - Toggle to isolate **"Bridge Nodes Only"** to spotlight friends who hold distinct friend circles together.
3. **Secret Admin Mode**:
   - Triggered via discreet header button or keyboard shortcut (`Ctrl + Shift + A`).
   - Modal requests secret nickname and password (defaults preconfigured, customizable).
   - Admin features:
     - **Add / Edit / Remove Friends**: Name, handle, web avatar URL, interests, custom bio.
     - **Add / Edit Connection**: Select Friend A and Friend B, choose connection strength (1 to 5 stars), and interaction notes.
     - **Auto-Cluster Engine**: Recalculates community groupings using mutual connection density and reassigns vibrant neon palettes.
     - **Backup / Restore**: Download JSON file of the graph or upload new JSON data. Reset to default demo at any time.

### Visual Identity & Theme
- **Aesthetic Direction**: Dark space galaxy network, deep obsidian void (`#090A0F`), with neon cluster colors (Electric Cyan `#00F0FF`, Magenta Rose `#FF007A`, Acid Lime `#10E775`, Amber Glow `#FFB800`, Ultra Violet `#9D4EDD`).
- **Shimmering & Flowing Animations**:
   - Animated edge dash offsets creating the sensation of light pulses streaming between friends.
   - Multi-color shimmering gradient rings around Bridge Nodes using CSS `@keyframes` and Canvas radial gradients.
   - Smooth dampening spring physics when dragging nodes or adjusting network gravity.
- **Typography & Clean UI**:
   - Headers: *Plus Jakarta Sans* / *Outfit* with sharp legibility.
   - Canvas Labels: Crisp white with dark stroke shadows ensuring readability at all zoom levels.
   - Metrics: Tabular numerals (`font-mono tabular-nums`) for connection counts and closeness ratings.

---

## 3. Key Product Decisions & Trade-Offs

- **Canvas-Based Graph Engine vs. Pure DOM**:
  - *Chosen Approach*: High-performance 2D Canvas with requestAnimationFrame loop and offscreen image caching for avatars, overlaid with React Tailwind HUD controls.
  - *Why*: Allows rendering dozens of nodes, hundreds of glowing edges, animated particles, and real-time zoom/pan without DOM lag.
- **Bridge Detection Algorithm (Betweenness & Cross-Cluster Density)**:
  - *Chosen Approach*: Automatic graph partition analyzer that evaluates the edge distribution of each node across detected communities. If a node has strong links to $\ge 2$ clusters where neither cluster dominates by more than 70%, the node is classified as a Bridge.
  - *Why*: Directly solves the user requirement ("не относили либо не туда либо не туда а выделяли как связующее звено").
- **Persistence & Secrets**:
  - *Chosen Approach*: `localStorage` with reactive state synchronization and export/import JSON.
  - *Why*: Instant, private, requires zero complex database servers for friend groups, and guarantees that user edits are saved across page reloads.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                          FriendAtlas Frontend                          │
│                                                                        │
│  ┌───────────────────────┐  ┌──────────────────────────────────────┐  │
│  │     Top Bar & HUD     │  │          Canvas Viewport             │  │
│  │  - Search friends     │  │  - Interactive Graph (Pan & Zoom)    │  │
│  │  - Tag/Cluster filter │  │  - Force-Directed Node Simulation    │  │
│  │  - Bridge-only toggle │  │  - Animated Beam Dashes & Shimmer    │  │
│  │  - Admin Lock button  │  │  - Avatar circles & Glowing halos    │  │
│  └───────────┬───────────┘  └──────────────────┬───────────────────┘  │
│              │                                 │                       │
│  ┌───────────▼─────────────────────────────────▼───────────────────┐  │
│  │                    Graph State Manager                          │  │
│  │  - Nodes State (size, avatar, tags, degree, bridgeScore)        │  │
│  │  - Edges State (source, target, weight, activity)               │  │
│  │  - Auto-Clustering & Bridge Detection Engine                    │  │
│  │  - LocalStorage Persister + JSON Export/Import                  │  │
│  └───────────┬─────────────────────────────────┬───────────────────┘  │
│              │                                 │                       │
│  ┌───────────▼───────────┐         ┌───────────▼───────────────────┐  │
│  │   Friend Detail Card  │         │     Secret Admin Console      │  │
│  │ - Friend profile      │         │ - Auth protection (nick/pass) │  │
│  │ - Connected friends   │         │ - Add/Edit/Delete Node        │  │
│  │ - Community breakdown │         │ - Add/Edit Connections        │  │
│  │ - Mutual friends list │         │ - Run Auto-Cluster Engine     │  │
│  └───────────────────────┘         └───────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

### Core Entities & Data Structure
- `FriendNode`:
  ```ts
  interface FriendNode {
    id: string;
    name: string;
    handle: string;
    avatarUrl?: string;
    interests: string[];
    bio?: string;
    customClusterId?: string;
    // Computed dynamically:
    clusterId: string;
    clusterColor: string;
    degree: number;
    weightedDegree: number;
    radius: number;
    isBridge: boolean;
    bridgeClusters?: string[];
    x?: number;
    y?: number;
    vx?: number;
    vy?: number;
  }
  ```
- `FriendEdge`:
  ```ts
  interface FriendEdge {
    id: string;
    source: string;
    target: string;
    strength: number; // 1 to 5
    relationshipType?: string; // e.g. "Gaming duo", "Best friends", "School buddy"
  }
  ```

---

## 5. Execution Steps
1. **Dependencies**: Install `d3-force` and `@types/d3-force` for industrial-strength organic force simulation and clustering physics.
2. **Preset Dataset**: Create a rich starter dataset of friend nodes and realistic cross-group edges with avatars and interest tags.
3. **Graph Engine Component**: Build the high-performance Canvas renderer with zoom/pan, glowing curved/straight links, animated dashing, hover/selection halos, and bridge shimmer rings.
4. **Community & Bridge Engine**: Implement the modularity clustering and bridge node detector.
5. **Interactive Controls & Inspect Sidebar**: Top bar with search, filter pills, statistics, and detail drawer for selected friends.
6. **Secret Admin Portal**: Protected view with password validation, intuitive node/connection editors, and JSON import/export.
7. **Verification & Polish**: Run `compile_applet` and test responsiveness, touch/mouse drag physics, and animations.
